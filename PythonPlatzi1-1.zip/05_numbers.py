lives = 3
print(lives)
print(type(lives))

age = 38
budget = 100

temperature = 12.12
print(temperature)
print(type(temperature))

lives = 12 + 15
print(lives)

lives = lives - 1
print(lives)

lives -= 1
print(lives)

lives -= 5
print(lives)

lives += 5
print(lives)

number = 45000000000000000000000000000.1
print(number)

numberB = 0.000000000000000000000012
print(numberB)

#ejercicio
budget = int(input("¿cual es tu primer presupuesto?"))
budget2 = int(input("¿cual es tu segundo presupuesto?"))
budget3 = int(input("¿cual es tu tercer presupuesto?"))

budgetPromedio = (budget + budget2 + budget3)/3
print(f"el promedio de los tres presupuesto es {budgetPromedio}")