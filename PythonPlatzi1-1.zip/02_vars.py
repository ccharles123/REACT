print("hola vars")
myName = "Mariana"
myAge = 12

print(myName)
print(myAge)

myName = "Betty"
print("aqui cambio", myName)

#input

myName = input("¿cual es tu nombre? ")
print("usando input", myName)

myAge = input("¿cual es tu edad? ")
print ("tu age es:", myAge)