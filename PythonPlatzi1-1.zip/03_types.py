#string

myName = "Mariana"
myName = 'Betty'
print('my name is', myName)
print(type(myName))

#int
myAge = 12
print("my age is", myAge)
print(type(myAge))

#boolean

isSingle = True
print("I'm single", isSingle)
print(type(isSingle))

#input
myAge = input ("¿Cual es tu age? ")
print("my age is", myAge)
print(type(myAge))
