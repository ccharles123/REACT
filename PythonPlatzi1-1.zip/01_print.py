print("Hola Mundo practica 2")
print ("Hola Soy Mariana tengo 10 años")
print(12+5)
print(4*5)
print(8/2)

#hola estoy aprendiento python